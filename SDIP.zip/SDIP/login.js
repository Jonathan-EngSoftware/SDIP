window.onload = function() {
    var urlParams = new URLSearchParams(window.location.search);
    var erro = urlParams.get('erro');

    if(erro === 'credenciais_invalidas') {
        alert("Usuário ou senha inválidos.");
    } else if(erro === 'preparacao_consulta') {
        alert("Erro na preparação da consulta.");
    }
}

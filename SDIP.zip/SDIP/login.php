<script src="./login.js"></script>

<?php
session_start();

if(isset($_POST['login'])) {
    include_once('config.php');

    $email = $_POST['email'];
    $senha = $_POST['senha'];

    // Consulta SQL para verificar as credenciais
    $sql = "SELECT id, nome FROM cadastro WHERE email=? AND senha=?";
    $stmt = mysqli_stmt_init($conexao);

    if(mysqli_stmt_prepare($stmt, $sql)) {
        // Vincular os parâmetros aos placeholders na consulta
        mysqli_stmt_bind_param($stmt, "ss", $email, $senha);

        // Executar a consulta preparada
        mysqli_stmt_execute($stmt);

        // Armazenar o resultado da consulta
        mysqli_stmt_store_result($stmt);

        // Verificar se as credenciais são válidas
        if(mysqli_stmt_num_rows($stmt) == 1) {
            // Autenticar o usuário e redirecionar para a página de sucesso
            $_SESSION['email'] = $email;
            header("Location: dados.php");
            exit();
        } else {
            // Credenciais inválidas, redirecionar de volta para o formulário de login
            header("Location: index.php?erro=credenciais_invalidas");
            exit();
        }
    } else {
        // Erro na preparação da consulta, redirecionar de volta para o formulário de login
        header("Location: index.php?erro=preparacao_consulta");
        exit();
    }

    // Fechar a declaração preparada
    

    // Fechar a conexão
} else {
    // Redirecionar de volta para o formulário de login se a tentativa de acesso direto a este script for feita
    header("Location: index.php");
    exit();
}
?>
<?php
       if(isset($_POST['submit'])) {
        include_once('config.php');

        $nome = $_POST['nome'];
        $genero = $_POST['genero'];
        $email = $_POST['email'];
        $senha = $_POST['senha'];
        
       if(empty($senha)) {
        echo "Por favor, preencha o campo de senha.";
    } else {
        // Preparar a consulta SQL com placeholders (?)
        $sql = "INSERT INTO cadastro (nome, genero, email, senha)
                VALUES (?, ?, ?, ?)";
        
        // Inicializar uma declaração preparada
        $stmt = mysqli_stmt_init($conexao);
        if(mysqli_stmt_prepare($stmt, $sql)) {
            // Vincular os parâmetros aos placeholders na consulta
            mysqli_stmt_bind_param($stmt, "ssss", $nome, $genero, $email, $senha);

            // Executar a declaração preparada
            mysqli_stmt_execute($stmt);

            // Verificar se a inserção foi bem-sucedida
            if(mysqli_stmt_affected_rows($stmt) > 0) {
                echo "Registro inserido com sucesso.";
            } else {
                echo "Erro ao inserir registro.";
            }
        } else {
            echo "Erro na preparação da declaração.";
        }

        // Fechar a declaração e a conexão
        mysqli_stmt_close($stmt);
    }

    mysqli_close($conexao);
    }

?>




<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SDIP-MARCAÇÃO DE CONSULTAS</title>
    <link rel="stylesheet" href="./style.css">
</head>

<body>
    <div class="background">
    <header>
        <h2 class="logo">SDIP</h2> 
        <nav class="navegacao">
            <a href="index.php">Home</a>
            <a href="#" onclick="irParaSobrePage('sobre.html')">Sobre</a>
            <a href="#" onclick="irParaLogin('dados.html')"></a>
            <a href="#" onclick="irParaCadastro('cadastro.html')">Cadastros</a>
            <a href="#">Contato</a>
            <button class="btnLogin-popup">Login</button>
        </nav>
    </header>
        
    <div class="access">
        <span class="fechar-icon">
            <ion-icon name="close"></ion-icon>
        </span>

        <div class="form-box login"> 
            <h2>Login</h2>
            <form action="login.php" method="POST">
            <div class="input-box">
                <span class="icon"><ion-icon name="mail"></ion-icon></span> 
                <input type="email" name="email" required>
                <label>Email</label>
            </div>
            <div class="input-box">
                <span class="icon"><ion-icon name="lock-closed"></ion-icon></span>
                <input type="password" name="senha" required>
                <label>Senha</label>
            </div>
            <button type="submit" class="btn" name="login">Login</button>
            <div class="registrar-login" name="login" id="login">
             <p>Não tem conta? <a href="#" class="registrar-link">Cadastrar</a></p>
        </div>
    </form>
</div>


        <div class="form-box registrar"> 
            <h2>Cadastro</h2>
            <form action="index.php" method="POST">
                <div class="input-box">
                    <span class="icon"><ion-icon name="person"></ion-icon></span> 
                    <input type="text"  name="nome" id="nome" required>
                    <label>Nome do Usuário</label>
                </div>
                <div class="input-box">
                    <span class="icon" ><ion-icon name="transgender-outline"></ion-icon>
                    </span>
                    <label>Gênero</label>
                </div>
                <div class="marcar-desmarcar">
                    <label><input type="checkbox" name="genero" id="genero">
                       Masculino</label>  
               </div>
               <div class="marcar-desmarcar">
                <label><input type="checkbox" name="genero" id="genero">
                   Feminino</label>  
                </div>
                <div class="marcar-desmarcar">
                    <label><input type="checkbox" name="genero" id="genero">
                       Outros</label>  
               </div>
                <div class="input-box">
                    <span class="icon"><ion-icon name="mail"></ion-icon></span> 
                    <input type="email" name="email" id="email" required>
                    <label>Email</label>
                </div>
                <div class="input-box">
                    <span class="icon" ><ion-icon name="lock-closed"></ion-icon></span>
                    <input type="password" name="senha" id="senha" required>
                    <label>Senha</label>
                </div>

                <button type="submit" id ="submit" name="submit" class="btn">Registrar
                </button>

                <div class="registrar-login">
                     <p>Já tem uma conta? 
                        <a href="#"
                     class="login-link"> Login</a>   

                     </p>
                </div>
            </form>
        </div>
    </div>  
    
</div>


    <script src="./script.js"></script>
    <script src="./login.js"></script>
    <script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>
    
</body>
</html>
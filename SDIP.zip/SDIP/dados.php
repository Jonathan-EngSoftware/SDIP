<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>SDIP - Página Principal</title>
  <link rel="stylesheet" href="main-style.css">
  <!-- Inclua a biblioteca Health Icons via CDN -->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/healthicons/healthicons.min.css">
</head>
<body>

<header>
  <div class="container">
    <h1>SDIP</h1>
    <nav>
      <ul>
        <li><a href="index.php">Sair</a></li>
      </ul>
    </nav>
  </div>
</header>

<main>
  <div class="banner">
    <form class="search-form" action="#">
      <input type="text" class="search-input" placeholder="Pesquisar...">
      <button type="submit" class="search-button">
        Procurar
      </button>
    </form>
  </div>
  

  <div class="container">
    <div class="content">
      <div class="services">
        <div class="service">
          <button>Atendimento</button>
        </div>
        <div class="service">
          <button>Agendamento</button>
        </div>
        <div class="service">
          <button>Histórico do Paciente</button>
        </div>
        <div class="service">
          <button>Suporte</button>
        </div>
        <div class="service">
          <button>Consulta</button>
        </div>
        <div class="service">
          <button>Exames</button>
        </div>
        <div class="service">
          <button>Medicamentos</button>
        </div>
        <div class="service">
          <button>Emergência</button>
        </div>
      </div>
    </div>
  </div>
</main>

<footer>
  <div class="container">
    <p>&copy; SDIP 2024</p>
  </div>
</footer>

<script src="script.js"></script>
<script src="login.js"></script>
</body>
</html>
